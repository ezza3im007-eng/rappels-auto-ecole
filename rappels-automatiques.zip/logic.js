'use strict';
// Règles de rappel + messages. Aucune dépendance externe : testable seul.
process.env.TZ = process.env.TZ || 'Africa/Tunis';

const MIN = 60000, HOUR = 60 * MIN;
const STALE = 3 * HOUR;          // un rappel en retard de plus de 3 h n'est plus envoyé
const SCHOOL = 'Auto-École HN';

function local(d, t) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(d || '').trim());
  if (!m) return null;
  let hh = 8, mm = 0;
  const q = /^(\d{1,2}):(\d{2})/.exec(String(t || '').trim());
  if (q) { hh = +q[1]; mm = +q[2]; }
  return new Date(+m[1], +m[2] - 1, +m[3], hh, mm, 0);
}
function at(ev, daysBefore, h, m) {
  const c = new Date(ev.getTime());
  c.setDate(c.getDate() - daysBefore);
  c.setHours(h, m, 0, 0);
  return c;
}
const pad = n => String(n).padStart(2, '0');
const hm = d => `${pad(d.getHours())}:${pad(d.getMinutes())}`;
const jour = d => d.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' });

const TYPES = {
  c: { nom: 'leçon de conduite', Nom: 'Leçon de conduite', ic: '🚗', poss: 'votre leçon de conduite' },
  k: { nom: 'séance de code', Nom: 'Séance de code', ic: '📘', poss: 'votre séance de code' },
  e: { nom: 'examen', Nom: 'Examen', ic: '📝', poss: 'votre examen' }
};

/** Retourne les rappels à envoyer maintenant pour UN élève. */
function dueFor(student, now) {
  const out = [];
  const evs = [];
  let examInPlan = false;
  (student.plan || []).forEach(p => {
    const k = TYPES[p.k] ? p.k : 'c';
    const ev = local(p.d, p.t);
    if (!ev) return;
    if (k === 'e' && p.d === student.exam) examInPlan = true;
    evs.push({ k, ev, hasTime: true, d: p.d, t: p.t || '' });
  });
  if (!examInPlan && student.exam) {
    const ev = local(student.exam, null);
    if (ev) evs.push({ k: 'e', ev, hasTime: false, d: student.exam, t: '' });
  }
  evs.forEach(e => {
    const T = e.ev.getTime();
    const slots = [];
    if (e.k === 'e') {
      slots.push({ code: 'j3', when: at(e.ev, 3, 18, 0), quand: jour(e.ev) + (e.hasTime ? ' à ' + hm(e.ev) : ''), rel: 'dans 3 jours' });
      slots.push({ code: 'j1', when: at(e.ev, 1, 18, 0), quand: 'demain' + (e.hasTime ? ' à ' + hm(e.ev) : ''), rel: 'demain' });
      if (e.hasTime) slots.push({ code: 'h2', when: new Date(T - 2 * HOUR), quand: "aujourd'hui à " + hm(e.ev), rel: 'dans 2 heures', before: true });
      else slots.push({ code: 'j0', when: at(e.ev, 0, 7, 0), quand: "aujourd'hui", rel: "aujourd'hui" });
    } else {
      slots.push({ code: 'j1', when: at(e.ev, 1, 18, 0), quand: 'demain à ' + hm(e.ev), rel: 'demain à ' + hm(e.ev) });
      slots.push({ code: 'h2', when: new Date(T - 2 * HOUR), quand: "aujourd'hui à " + hm(e.ev), rel: 'dans 2 heures (' + hm(e.ev) + ')', before: true });
    }
    slots.forEach(s => {
      const w = s.when.getTime();
      if (w > now || now - w > STALE) return;          // pas encore l'heure, ou trop tard
      if (T <= now + 15 * MIN) return;                  // la séance est (presque) commencée
      out.push({
        key: [student.id, e.k, e.d, e.t, s.code].join('|'),
        type: e.k, code: s.code, quand: s.quand, rel: s.rel,
        heure: e.hasTime ? hm(e.ev) : '', when: w
      });
    });
  });
  return out;
}

function prenom(s) { return String(s.name || '').trim().split(/\s+/)[0] || ''; }

function buildMail(student, r) {
  const T = TYPES[r.type];
  const subject = `${T.ic} Rappel : ${T.nom} ${r.rel} — ${SCHOOL}`;
  const p = prenom(student);
  const line = r.type === 'e'
    ? `Rappel : ${T.poss} a lieu ${r.quand}.`
    : `Rappel : ${T.poss} est prévue ${r.quand}.`;
  const tip = r.type === 'e' ? 'Préparez vos documents, dormez bien et arrivez en avance. Bonne chance !' : 'Merci d\'être à l\'heure.';
  const text = `Bonjour ${p},\n\n${line}\n${tip}\n\n${SCHOOL}`;
  const html = `<div style="font-family:Arial,sans-serif;max-width:480px;margin:auto;border:1px solid #d5dce3;border-radius:12px;overflow:hidden">
<div style="background:#0B4F9C;color:#fff;padding:14px 18px;font-size:18px;font-weight:bold">${SCHOOL}</div>
<div style="padding:18px;color:#1B2A3A;font-size:16px;line-height:1.5">
<p>Bonjour ${esc(p)},</p><p><b>${T.ic} ${esc(line)}</b></p><p>${esc(tip)}</p></div></div>`;
  return { subject, text, html };
}

/** Paramètres du modèle WhatsApp « rappel_seance » : {{1}} prénom {{2}} séance {{3}} quand {{4}} conseil */
function buildWa(student, r) {
  const T = TYPES[r.type];
  const conseil = r.type === 'e' ? 'Bonne chance et arrivez en avance !' : "Merci d'être à l'heure.";
  return [prenom(student) || 'cher élève', T.poss, r.quand, conseil];
}

function esc(t) { return String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }

/** Numéro au format international sans « + » (Tunisie par défaut). */
function phone(raw) {
  let d = String(raw || '').replace(/[^\d+]/g, '');
  if (!d) return null;
  d = d.replace(/^\+/, '');
  if (d.startsWith('00')) d = d.slice(2);
  if (/^\d{8}$/.test(d)) d = '216' + d;
  if (d.startsWith('2160') && d.length === 12) d = '216' + d.slice(4);
  return /^\d{10,15}$/.test(d) ? d : null;
}
function email(raw) {
  const m = String(raw || '').trim().toLowerCase();
  return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(m) ? m : null;
}

module.exports = { dueFor, buildMail, buildWa, phone, email, local, TYPES, SCHOOL };
