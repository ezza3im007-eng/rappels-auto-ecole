'use strict';
const crypto = require('crypto');
const { dueFor, buildMail, buildWa, phone, email, SCHOOL } = require('./logic');

const DRY = process.env.DRY_RUN === '1' || process.argv.includes('--dry-run');
const WA = {
  token: process.env.WA_TOKEN, phoneId: process.env.WA_PHONE_ID,
  template: process.env.WA_TEMPLATE || 'rappel_seance', lang: process.env.WA_LANG || 'fr'
};
const SMTP = {
  user: process.env.SMTP_USER, pass: process.env.SMTP_PASS,
  host: process.env.SMTP_HOST, port: Number(process.env.SMTP_PORT || 465),
  from: process.env.MAIL_FROM || (process.env.SMTP_USER ? `${SCHOOL} <${process.env.SMTP_USER}>` : '')
};
const canMail = !!(SMTP.user && SMTP.pass), canWa = !!(WA.token && WA.phoneId);

async function loadStudents() {
  if (process.env.MOCK_FILE) {
    const m = JSON.parse(require('fs').readFileSync(process.env.MOCK_FILE, 'utf8'));
    return { students: m.students, log: new Set(m.alreadySent || []), mark: async () => {} };
  }
  const admin = require('firebase-admin');
  const sa = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT || '{}');
  if (!sa.project_id) throw new Error('Secret FIREBASE_SERVICE_ACCOUNT manquant ou invalide.');
  admin.initializeApp({ credential: admin.credential.cert(sa) });
  const db = admin.firestore();
  const snap = await db.collection('eleves').get();
  const students = snap.docs.map(d => Object.assign({ id: d.id }, d.data()));
  const hash = k => crypto.createHash('sha1').update(k).digest('hex');
  return {
    students,
    isDone: async k => (await db.collection('rappels_envoyes').doc(hash(k)).get()).exists,
    mark: async (k, info) => db.collection('rappels_envoyes').doc(hash(k)).set(Object.assign({ key: k, at: Date.now() }, info))
  };
}

async function sendMail(to, m) {
  const nodemailer = require('nodemailer');
  const tr = nodemailer.createTransport(SMTP.host
    ? { host: SMTP.host, port: SMTP.port, secure: SMTP.port === 465, auth: { user: SMTP.user, pass: SMTP.pass } }
    : { service: 'gmail', auth: { user: SMTP.user, pass: SMTP.pass } });
  await tr.sendMail({ from: SMTP.from, to, subject: m.subject, text: m.text, html: m.html });
}

async function sendWa(to, params) {
  const r = await fetch(`https://graph.facebook.com/v21.0/${WA.phoneId}/messages`, {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + WA.token, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      messaging_product: 'whatsapp', to, type: 'template',
      template: { name: WA.template, language: { code: WA.lang }, components: [{ type: 'body', parameters: params.map(t => ({ type: 'text', text: String(t).replace(/\s+/g, ' ').slice(0, 300) })) }] }
    })
  });
  if (!r.ok) throw new Error('WhatsApp HTTP ' + r.status + ' ' + (await r.text()).slice(0, 300));
}

async function main() {
  const now = process.env.NOW ? new Date(process.env.NOW).getTime() : Date.now();
  console.log(`[${new Date(now).toLocaleString('fr-FR')}] ${DRY ? 'TEST (rien n\'est envoyé)' : 'Envoi réel'} — e-mail ${canMail ? 'prêt' : 'non configuré'}, WhatsApp ${canWa ? 'prêt' : 'non configuré'}`);
  const src = await loadStudents();
  let sent = 0, failed = 0, skipped = 0;
  for (const s of src.students) {
    const due = dueFor(s, now);
    for (const r of due) {
      const jobs = [];
      const to = email(s.mail), ph = phone(s.tel);
      if (to && (canMail || DRY)) jobs.push(['mail', to]);
      if (ph && (canWa || DRY)) jobs.push(['wa', ph]);
      if (!jobs.length) { console.log(`  ! ${s.name}: ni e-mail ni téléphone valide/configuré pour « ${r.key} »`); skipped++; continue; }
      for (const [ch, dest] of jobs) {
        const k = r.key + '|' + ch;
        const done = src.isDone ? await src.isDone(k) : src.log.has(k);
        if (done) { skipped++; continue; }
        try {
          if (DRY) console.log(`  → [${ch}] ${s.name} <${dest}> : ${ch === 'mail' ? buildMail(s, r).subject : JSON.stringify(buildWa(s, r))}`);
          else {
            if (ch === 'mail') await sendMail(dest, buildMail(s, r));
            else await sendWa(dest, buildWa(s, r));
            await src.mark(k, { eleve: s.id, canal: ch });
            console.log(`  ✓ [${ch}] ${s.name} : ${r.key}`);
          }
          sent++;
        } catch (e) { failed++; console.error(`  ✗ [${ch}] ${s.name} : ${e.message}`); }
      }
    }
  }
  console.log(`Terminé : ${sent} message(s) ${DRY ? 'simulés' : 'envoyés'}, ${skipped} ignoré(s), ${failed} échec(s).`);
  if (failed && !DRY) process.exitCode = 1;
}
main().catch(e => { console.error('Erreur :', e.message); process.exit(1); });
