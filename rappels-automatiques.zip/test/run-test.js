'use strict';
process.env.TZ = 'Africa/Tunis';
const assert = require('node:assert');
const { dueFor, phone, email, buildWa, buildMail, local } = require('../logic');
const at = s => local(s.slice(0, 10), s.slice(11)).getTime();

// numéros
assert.strictEqual(phone('22 123 456'), '21622123456');
assert.strictEqual(phone('+216 98 765 432'), '21698765432');
assert.strictEqual(phone('00216 55 111 222'), '21655111222');
assert.strictEqual(phone('abc'), null);
assert.strictEqual(email(' A@B.tn '), 'a@b.tn'); assert.strictEqual(email('nope'), null);

const s = { id: 's1', name: 'Sami Ben Ali', exam: '2026-10-20', plan: [
  { d: '2026-10-06', t: '10:00', k: 'c' }, { d: '2026-10-20', t: '09:00', k: 'e' }] };

// 18h veille : envoyé à 18:10 le 5, pas à 17:50
assert.deepStrictEqual(dueFor(s, at('2026-10-05 17:50')).map(r => r.code), []);
let r = dueFor(s, at('2026-10-05 18:10')); assert.strictEqual(r.length, 1); assert.strictEqual(r[0].code, 'j1'); assert.strictEqual(r[0].quand, 'demain à 10:00');
// 2 h avant : 08:10 le 6
r = dueFor(s, at('2026-10-06 08:10')); assert.deepStrictEqual(r.map(x => x.code), ['h2']);
// trop tard (retard > 3 h) : plus rien à 11h après la séance
assert.deepStrictEqual(dueFor(s, at('2026-10-06 13:30')).map(x => x.code), []);
// séance dans 10 min : rien (rappel inutile)
assert.deepStrictEqual(dueFor({ id: 'x', plan: [{ d: '2026-10-06', t: '10:00' }] }, at('2026-10-06 09:50')), []);
// retard de cron : le rappel de la veille (18h) envoyé à 19:30 est encore accepté
assert.strictEqual(dueFor(s, at('2026-10-05 19:30')).length, 1);
// examen : J-3, J-1, 2 h avant ; pas de doublon entre plan et champ exam
assert.deepStrictEqual(dueFor(s, at('2026-10-17 18:05')).map(x => x.code), ['j3']);
assert.deepStrictEqual(dueFor(s, at('2026-10-19 18:05')).map(x => x.code), ['j1']);
assert.deepStrictEqual(dueFor(s, at('2026-10-20 07:05')).map(x => x.code), ['h2']);
// examen sans heure : jour J à 7h
const ex = { id: 'e', exam: '2026-11-02', plan: [] };
assert.deepStrictEqual(dueFor(ex, at('2026-11-02 07:20')).map(x => x.code), ['j0']);
// messages
const m = buildMail(s, dueFor(s, at('2026-10-05 18:10'))[0]);
assert.ok(m.subject.includes('leçon de conduite') && m.subject.includes('Auto-École HN'));
assert.deepStrictEqual(buildWa(s, dueFor(s, at('2026-10-05 18:10'))[0]), ['Sami', 'votre leçon de conduite', 'demain à 10:00', "Merci d'être à l'heure."]);
// données invalides
assert.deepStrictEqual(dueFor({ id: 'z', plan: [{ d: 'abc' }, {}, null].filter(Boolean) }, Date.now()), []);
console.log('Tous les tests passent ✔');
